# potential-enigma
Linear Regression from scratch

This repo is associated with [this](https://mubaris.com/2017-09-28/linear-regression-from-scratch) blog post.
